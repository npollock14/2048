
public class Board {

	public int nextMove(int[][] board) {

		return 0;
	}

}
