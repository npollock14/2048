import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class SolutionTester {
	public static ArrayList<String> bad = new ArrayList<String>();
	public static ArrayList<String> good = new ArrayList<String>();

	public static boolean cheater = false;

	public static void main(String[] arg) {

		Solution sol = new Solution();
		Board b = new Board();

		for (int i = 0; i < 2000; i++) {
			int n = b.nextMove(sol.getBoard());
			String res = (Arrays.deepToString(sol.getBoard()));
			res = res.replaceAll("],", "]\n");
			//res = res.replaceAll("[" + "[", "[");
			res = res.replaceAll("]" + "]", "]\n");
			System.out.println(res);
			
			
			if (n < 0 || n > 3) {
				cheater = true;
			}
			sol.nextMove(n);
		}

		int[] res = getMax(sol.getBoard());

		printResult(res);

	}

	public static int[] getMax(int[][] b) {
		int max = b[0][0];
		int sum = 0;
		for (int[] row : b) {
			for (int x : row) {
				if (x > max)
					max = x;
				sum += x;
			}
		}

		return new int[] { max, sum };
	}

	public static String print(String msg, boolean fail) {

		if (!fail) {
			return "Passed " + msg;
		} else {
			return "Failed " + msg;
		}

	}

	public static void printResult(int[] res) {
		int score = 0;
		int x = 0;
		System.out.println("Successes");
		System.out.println("==========");

		for (String str : good) {
			System.out.println(x + ":\t " + str);
			score += 1;
			x++;
		}
		x = 0;
		System.out.println("==========");
		System.out.println("Failures");
		System.out.println("==========");
		for (String str : bad) {
			System.out.println(x + ":\t" + str);
			x++;
		}
		System.out.println();
		System.out.println("Max Tile: " + res[0]);
		System.out.println("Sum Tiles: " + res[1]);
		System.out.println("Score: ");
		if (cheater) {
			System.out.println("-1 : Score Invalidated - Cheaters never win");
		} else {
			System.out.print(res[0] + res[1]);
		}
	}

}

class Solution {

	private int[][] board;
	private Random rnd = new Random(0); // setup random # generator

	public Solution() {
		board = new int[4][4];
		populateOne();
		populateOne();
	}

	public void populateOne() {
		int randomNum = rnd.nextInt(10);
		int newNum;
		if (randomNum == 0) {
			newNum = 4;
		} else {
			newNum = 2;
		}

		boolean done = !hasZeros();

		while (!done) {
			int row = rnd.nextInt(4);
			int col = rnd.nextInt(4);
			if (board[row][col] == 0) {
				board[row][col] = newNum;
				done = true;
			}
		}
	}

	public boolean hasZeros() {
		for (int[] i : board) {
			for (int j : i) {
				if (j == 0) {
					return true;
				}
			}
		}
		return false;
	}

	public void slideRight(int[] row) {
		boolean swap = false;
		while (true) {
			swap = false;
			for (int i = 0; i < row.length - 1; i++) {
				if (row[i] != 0 && row[i + 1] == 0) {
					row[i + 1] = row[i];
					row[i] = 0;
					swap = true;
				}
			}
			if (!swap) {
				break;
			}
		}
	}

	/*
	 * 
	 * Move the numbers as far to the right as they can go
	 * 
	 * aka the numbers are trying to move to the right-most
	 * 
	 * empty spaces. This method must utilize the slideRight(int[] row) method
	 * 
	 * must utilize the helper method above for full credit.
	 * 
	 * param: a valid row of 2048 where 0s are "empty" spots
	 * 
	 * effect: row is modified so all numbers are to the right side
	 * 
	 * return: none
	 */

	public void slideRight() {

		// go through 2D array, move all digits as far right as possible
		for (int i = 0; i < board.length; i++) {
			slideRight(board[i]);
		}
		// you should not overwriting values

	}

	/**
	 * Given an array of integers, slide all non-zero elements to the left.
	 * 
	 * zero elements are considered open spots.
	 * 
	 * example : * [0 2 0 2] -> [2 2 0 0]
	 * 
	 * [2 0 0 2] -> [2 2 0 0]
	 */

	public void slideLeft(int[] row) {
		boolean swap = false;

		while (true) {
			swap = false;
			for (int i = 1; i < row.length; i++) {
				if (row[i] != 0 && row[i - 1] == 0) {
					row[i - 1] = row[i];
					row[i] = 0;
					swap = true;
				}
			}
			if (!swap) {
				break;
			}
		}
	}

	/*
	 * Slide all the numbers to the left so that
	 * 
	 * all of the empty spaces are on the right side
	 */

	public void slideLeft() {
		for (int i = 0; i < board.length; i++) {
			slideLeft(board[i]);
		}
	}

	/**
	 * Given a 2D array and a column number, return a 1D array representing the
	 * elements in the given column number.
	 */

	public int[] getCol(int[][] data, int c) {
		int[] result = new int[4];

		for (int i = 0; i < data.length; i++) {
			result[i] = data[i][c];
		}

		return result;
	}

	/**
	 * Given an array of integers, slide all non-zero elements to the top.
	 * 
	 * zero elements are considered open spots.
	 */

	public int[] slideUp(int[] col) {
		slideLeft(col);
		return col;
	}

	/*
	 * 
	 * Slide all elements in the board towards the top.
	 * 
	 * You must use slideUp and getCol for full credit.
	 */

	public void slideUp() {
		for (int i = 0; i < board[0].length; i++) {
			int[] col = slideUp(getCol(board, i));
			for (int j = 0; j < board.length; j++) {
				board[j][i] = col[j];
			}
		}
	}

	public int[] slideDown(int[] col) {
		slideRight(col);
		return col;
	}

	/*
	 * slide all the numbers down so that any
	 * 
	 * empty space is at the top
	 * 
	 * You must use slideDown and getCol for full credit.
	 */

	public void slideDown() {
		for (int i = 0; i < board[0].length; i++) {
			int[] col = slideDown(getCol(board, i));
			for (int j = 0; j < board.length; j++) {
				board[j][i] = col[j];
			}
		}
	}

	/*
	 * Given the 2D array, board, combineRight will take adjacent numbers that are
	 * the same and combine them (add them).
	 * 
	 * After adding them together, one of the numbers is zeroed out. For example, if
	 * row 0 contained [0 0 4 4],
	 * 
	 * a call to combineRight will produce [0 0 0 8]. If row 1 contained [2 2 2 2],
	 * a call to combineRight will
	 * 
	 * produce [0 4 0 4].
	 * 
	 * Notice that the left element is zeroed out.
	 */

	public void combineRight() {
		// slideRight();
		for (int i = board[0].length - 1; i >= 0; i--) {
			for (int j = board[i].length - 2; j >= 0; j--) {
				if (board[i][j + 1] == board[i][j] && board[i][j] != 0) {
					board[i][j] = 0;
					board[i][j + 1] = board[i][j + 1] * 2;
				}
			}
		}

		// slideRight();
	}

	/*
	 * same behavior as combineRight but the right element is zeroed out when two
	 * elements are combined
	 */

	public void combineLeft() {
		// slideLeft();

		for (int i = 0; i < board[0].length; i++) {
			for (int j = 1; j < board[i].length; j++) {
				if (board[i][j - 1] == board[i][j] && board[i][j] != 0) {
					board[i][j] = 0;
					board[i][j - 1] = board[i][j - 1] * 2;
					j++;
				}
			}
		}
		// slideLeft();
	}

	/*
	 * same behavior as combineRight but the bottom element is zeroed out when two
	 * elements are combined
	 */

	public void combineUp() {
		slideUp();
		for (int i = 0; i < board[0].length; i++) {
			int[] col = slideUp(getCol(board, i));

			for (int j = 1; j < col.length; j++) {
				if (col[j - 1] == col[j] && col[j] != 0) {
					col[j] = 0;
					col[j - 1] = col[j - 1] * 2;
					j++;
				}
			}

			for (int k = 0; k < board.length; k++) {
				board[k][i] = col[k];
			}
		}

		slideUp();
	}

	/*
	 * same behavior as combineRight but the top element is zeroed out when two
	 * elements are combined
	 */

	public void combineDown() {
		slideDown();
		for (int i = 0; i < board[0].length; i++) {
			int[] col = slideDown(getCol(board, i));

			for (int j = col.length - 2; j >= 0; j--) {
				if (col[j + 1] == col[j] && col[j] != 0) {
					col[j] = 0;
					col[j + 1] = col[j + 1] * 2;
					j--;
				}
			}

			for (int k = 0; k < board.length; k++) {
				board[k][i] = col[k];
			}
		}
		slideDown();
	}

	public void left() {
		slideLeft();
		combineLeft();
		slideLeft();
	}

	public void right() {
		slideRight();
		combineRight();
		slideRight();
	}

	public void up() {
		slideUp();
		combineUp();
		slideUp();
	}

	public void down() {
		slideDown();
		combineDown();
		slideDown();
	}

	public boolean gameOver() {
		return false;
	}

	public int[][] getBoard() {

		int[][] b = new int[4][4];
		for (int r = 0; r < 4; r++) {
			for (int c = 0; c < 4; c++) {
				b[r][c] = board[r][c];
			}
		}

		return b;
	}

	public void nextMove(int n) {
		switch (n) {
		case 0:
			left();
			break;

		case 1:
			right();
			break;

		case 2:
			up();
			break;

		case 3:
			down();
			break;

		}

		populateOne();
	}

	// populate with a given 2d array
	public void populate(int[][] arr) {
		for (int r = 0; r < arr.length; r++) {
			for (int c = 0; c < arr[r].length; c++) {
				board[r][c] = arr[r][c];
			}
		}
		// populateOne();
		// populateOne();
	}

}